//
// Created by hiccup on 2023/9/18.
//


#include "driver/Driver.h"

int main() {
    Driver driver;
    driver.runCompiler();
    return 0;
}