//
// Created by hiccup on 2023/11/14.
//

#include "MipsOperand.h"

MipsRegPtr $zero = new MipsReg("$zero");
MipsRegPtr $v0 = new MipsReg("$v0");
MipsRegPtr $v1 = new MipsReg("$v1");
MipsRegPtr $a0 = new MipsReg("$a0");
MipsRegPtr $a1 = new MipsReg("$a1");
MipsRegPtr $a2 = new MipsReg("$a2");
MipsRegPtr $a3 = new MipsReg("$a3");
MipsRegPtr $t0 = new MipsReg("$t0");
MipsRegPtr $t1 = new MipsReg("$t1");
MipsRegPtr $t2 = new MipsReg("$t2");
MipsRegPtr $t3 = new MipsReg("$t3");
MipsRegPtr $t4 = new MipsReg("$t4");
MipsRegPtr $t5 = new MipsReg("$t5");
MipsRegPtr $t6 = new MipsReg("$t6");
MipsRegPtr $t7 = new MipsReg("$t7");
MipsRegPtr $s0 = new MipsReg("$s0");
MipsRegPtr $s1 = new MipsReg("$s1");
MipsRegPtr $s2 = new MipsReg("$s2");
MipsRegPtr $s3 = new MipsReg("$s3");
MipsRegPtr $s4 = new MipsReg("$s4");
MipsRegPtr $s5 = new MipsReg("$s5");
MipsRegPtr $s6 = new MipsReg("$s6");
MipsRegPtr $s7 = new MipsReg("$s7");
MipsRegPtr $t8 = new MipsReg("$t8");
MipsRegPtr $t9 = new MipsReg("$t9");
MipsRegPtr $k0 = new MipsReg("$k0");
MipsRegPtr $k1 = new MipsReg("$k1");
MipsRegPtr $gp = new MipsReg("$gp");
MipsRegPtr $sp = new MipsReg("$sp");
MipsRegPtr $fp = new MipsReg("$fp");
MipsRegPtr $ra = new MipsReg("$ra");