//
// Created by hiccup on 2023/10/1.
//
#include "Symbol.hpp"

Symbol symbol;
vector<pair<Exception, int>> errorList{};